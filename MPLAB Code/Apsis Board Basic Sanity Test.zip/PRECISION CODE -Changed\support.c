/*********************************************************************
	filename	:support.c
	description	:It contain the support function _debounce .
	author		:apsis_team
	date		:18.10.2011

***********************************************************************/


#include "support.h"

void _Debounce(void)
{
   unsigned int i = 0;
   for (i = 0; i <= 100 ; i++);
}

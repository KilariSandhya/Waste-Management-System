#define FREQUENCY_1MHZ		0
#define FREQUENCY_2MHZ		1
#define FREQUENCY_4MHZ		2
#define FREQUENCY_8MHZ		3
#define FREQUENCY_16MHZ		4

#define FREQUENCY	FREQUENCY_4MHZ

void fn_Set_Clock_Frequency(void);



/*
    filename		:ProjectMain.c
	description		:Precision Farming
	author			:apsis_team
	date			:2017-06-12
	Last Changed by : AJITH K R
*/

#include <p18f46k22.h>    
#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include <delays.h>

#include "ProjectMain.h"  
#include "serial_codes.h"
#include "ADC.H" 
#include "PinAllocation.h"
#include "LCD.h"
#include "delay.h"
#include "timers.h"


#define TEMP_SENSOR_LOW_THRESHOLD                       67    ///before 58
#define TEMP_SENSOR_HIGH_THRESHOLD						71
#define HUMIDITY_SENSOR_LOW_THRESHOLD					355
#define HUMIDITY_SENSOR_HIGH_THRESHOLD					620
#define SOIL_MOISITURE_SENSOR_ZONE1_LOW_THRESHOLD		900
#define SOIL_MOISITURE_SENSOR_ZONE1_HIGH_THRESHOLD      350
#define SOIL_MOISITURE_SENSOR_ZONE2_LOW_THRESHOLD       900
#define SOIL_MOISITURE_SENSOR_ZONE2_HIGH_THRESHOLD      350
#define PH_SENSOR_THRESHOLD 					        620

#define RFID_FERTILZER1 "0007168555"  	/// valid card
#define RFID_FERTILZER2 "0007181103"  	/// valid card
#define RFID_FERTILZER3 "0007181102"	/// NOT valid card
#define RFID_PESTICIDE1 "0003798242"	/// valid card
#define RFID_PESTICIDE2 "0007181119"	/// valid card
#define RFID_PESTICIDE3 "0007177421"	///NOT  valid card



unsigned char guchLCDLine1String[17],guchLCDLine2String[17];
unsigned int unTempSensorADCValue,unHumiditySensorADCValue,unSoilMoistSensorADCValueZone1,unSoilMoistSensorADCValueZone2,unPHSensorADCValue;
unsigned char fan_Status=0,bulb_Status=0;
unsigned char RFID_CARDvalue;
unsigned SerialData;


unsigned char guchTemperatureStatus_LCD[8];
unsigned char guchHumidityStatus_LCD[8];
unsigned char guchSoilMoisitureZone1_LCD[8];
unsigned char guchSoilMoisitureZone2_LCD[8];

unsigned char guchDatatoWebFertiliZer[10];
unsigned char guchDatatoWebPesticide[10];

void fnMain_Project()
{
	
	unsigned int unDataUploadTowebsiteCounter=0;
	
	Dir_FERTILIZER_MODE_SWITCH=SET_INPUT;
	Dir_PESTCIDE_MODE_SWITCH=SET_INPUT;
	Dir_EXHAUST_FAN_OUT=SET_OUTPUT;
    Dir_WATER_MOTOR1=SET_OUTPUT;
	Dir_WATER_MOTOR2=SET_OUTPUT;
	Dir_FAN_OUT=SET_OUTPUT;
	BULB_OUT=OFF;
	FAN_OUT=OFF;
	EXHAUST_FAN_OUT=OFF;
	
	while(1)
	{
		unTempSensorADCValue	=	unfnReadADCChannel(TEMP_SENSOR_CHANNEL,ADC_10BIT_MODE);
		unHumiditySensorADCValue =unfnReadADCChannel(HUMIDITY_SENSOR_CHANNEL,ADC_10BIT_MODE);
		unSoilMoistSensorADCValueZone1=unfnReadADCChannel(SOIL_MOISTURE_SENSOR_ZONE1_CHANNEL,ADC_10BIT_MODE);
		unSoilMoistSensorADCValueZone2=unfnReadADCChannel(SOIL_MOISTURE_SENSOR_ZONE2_CHANNEL,ADC_10BIT_MODE);
		unPHSensorADCValue=unfnReadADCChannel(PH_SENSOR_CHANNEL,ADC_10BIT_MODE);
		printf("Tempearture in the farm = %d\n\r",unTempSensorADCValue);
		printf("Humidity in air	=	%d\n\r",unHumiditySensorADCValue);
		printf("moisture in ZONE 1 soil	=	%d\n\r",unSoilMoistSensorADCValueZone1);	
	   	printf("moisture in ZONE 2 soil	=	%d\n\r",unSoilMoistSensorADCValueZone2);
	    printf("PH ADC values is = %d \n\r",unPHSensorADCValue);
	    if(FERTILIZER_MODE_SWITCH==PRESSED)
	     {
	     
          printf("Fertilizer  entry mode\n\r");
	     	fnFertilizerInput();
	     
	     }
	    if(PESTCIDE_MODE_SWITCH==PRESSED)
	   {
	     printf("PESTICIDE entry mode\n\r");
	   	 fnPestcideInput();
	   }

	if(unPHSensorADCValue>PH_SENSOR_THRESHOLD)
		{
		
		
			printf("PH is low \n\r ");
			printf("Apply Fertilizer \n\r");
			fn_clear_display();
			strcpypgm2ram(guchLCDLine1String,"   PH =LOW        ");
			strcpypgm2ram(guchLCDLine2String," Apply Fertilizer ");
			fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
			fn_Display_String_LCD(guchLCDLine1String);
			fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_0);
			fn_Display_String_LCD(guchLCDLine2String);	
			delay_in_half_seconds(2);
	    
		
	}
	else 
	{
		
		printf("PH is normal \n\r ");
		printf("Fertilizer  not required\n\r");
		fn_clear_display();
		strcpypgm2ram(guchLCDLine1String,"   PH =NORMAL     ");
		strcpypgm2ram(guchLCDLine2String,"                  ");
		fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
		fn_Display_String_LCD(guchLCDLine1String);
		fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_0);
		fn_Display_String_LCD(guchLCDLine2String);	
		delay_in_half_seconds(2);
		
	}
	
		if(unTempSensorADCValue	<=	TEMP_SENSOR_LOW_THRESHOLD)
		{
		 	BULB_OUT		=		ON;
		 	printf("temperature is low  BULB is ON \n\r");
			//LCD fuction TEMP=L
			strcpypgm2ram(guchTemperatureStatus_LCD,"TEMP=L  ");
		 	fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
	     	fn_Display_String_LCD(guchTemperatureStatus_LCD);
				
		}
		
		
		
		else if(unTempSensorADCValue	>=	TEMP_SENSOR_HIGH_THRESHOLD)
		{
			BULB_OUT		=		OFF;
			EXHAUST_FAN_OUT			=		ON;
			printf("temperature is HIgh Fan is ON \n\r");
			//LCD fuction TEMP=H
			strcpypgm2ram(guchTemperatureStatus_LCD,"TEMP=H  ");
		 	fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
	     	fn_Display_String_LCD(guchTemperatureStatus_LCD);	
		}
		else
		{
			EXHAUST_FAN_OUT	=OFF;
			BULB_OUT	=OFF;
			
			printf(" Temperature Normal condition\n\r");
			//LCD fuction TEMP=N
			
			strcpypgm2ram(guchTemperatureStatus_LCD,"TEMP=N  ");
		 	fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
	     	fn_Display_String_LCD(guchTemperatureStatus_LCD);
		}
        if(unHumiditySensorADCValue<HUMIDITY_SENSOR_LOW_THRESHOLD)
        {
        
	        FAN_OUT=ON;
	        
	        //LCD fuction HUM=L
	        printf(" Humidity is Low\n");
	        
			strcpypgm2ram(guchHumidityStatus_LCD,"HUM=L   ");
		 	fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_9);
	     	fn_Display_String_LCD(guchHumidityStatus_LCD);
        }
		else if(unHumiditySensorADCValue>HUMIDITY_SENSOR_HIGH_THRESHOLD)
		{
			 FAN_OUT=OFF;
			 //LCD fuction HUM=H
			 printf(" Humidity is HIGH\n");
			 
			strcpypgm2ram(guchHumidityStatus_LCD,"HUM=H   ");
		 	fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_9);
	     	fn_Display_String_LCD(guchHumidityStatus_LCD);
		}
		else
		{
			FAN_OUT=OFF;
			printf("Humidity is normal\n");
			
			strcpypgm2ram(guchHumidityStatus_LCD,"HUM=N   ");
		 	fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_9);
	     	fn_Display_String_LCD(guchHumidityStatus_LCD);
			 //LCD fuction HUM=N
		}
		
				
		if(unSoilMoistSensorADCValueZone1>=SOIL_MOISITURE_SENSOR_ZONE1_LOW_THRESHOLD)
		{
		
			WATER_MOTOR1=ON;
			//LCD fuction SM1=L
			printf(" SoilMoisture in Zone1 is Low\n");
			
			strcpypgm2ram(guchSoilMoisitureZone1_LCD,"SMZ1=L  ");
		 	fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
	     	fn_Display_String_LCD(guchSoilMoisitureZone1_LCD);
		
		}
		else if(unSoilMoistSensorADCValueZone1<=SOIL_MOISITURE_SENSOR_ZONE1_HIGH_THRESHOLD)
		
		{

			WATER_MOTOR1=OFF;
				//LCD fuction SM1=H
			printf(" SoilMoisture in Zone1 is High\n");
				
				
			strcpypgm2ram(guchSoilMoisitureZone1_LCD,"SMZ1=H  ");
		 	fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_0);
	     	fn_Display_String_LCD(guchSoilMoisitureZone1_LCD);
		
		}
		else
		{
			WATER_MOTOR1=OFF;
			//LCD fuction SM1=N
			printf(" SoilMoisture in Zone1 is Normal\n");
				
				
			strcpypgm2ram(guchSoilMoisitureZone1_LCD,"SMZ1=N  ");
		 	fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_0);
	     	fn_Display_String_LCD(guchSoilMoisitureZone1_LCD);
			
		}
	   
	   	if(unSoilMoistSensorADCValueZone2>=SOIL_MOISITURE_SENSOR_ZONE2_LOW_THRESHOLD)
		{
		
			WATER_MOTOR2=ON;
			//LCD fuction SM2=L
			printf(" SoilMoisture in Zone2 is Low\n");
					
				
			strcpypgm2ram(guchSoilMoisitureZone2_LCD,"SMZ2=L  ");
		 	fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_9);
	     	fn_Display_String_LCD(guchSoilMoisitureZone2_LCD);
		
		}
		else if(unSoilMoistSensorADCValueZone2<=SOIL_MOISITURE_SENSOR_ZONE1_HIGH_THRESHOLD)
		
		{
			WATER_MOTOR2=OFF;
				//LCD fuction SM2=H
			printf(" SoilMoisture in Zone2 is High\n");
				
			strcpypgm2ram(guchSoilMoisitureZone2_LCD,"SMZ2=H  ");
		 	fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_9);
	     	fn_Display_String_LCD(guchSoilMoisitureZone2_LCD);
				
			
		}
		else
		{
			WATER_MOTOR2=OFF;
			//LCD fuction SM2=N
			printf(" SoilMoisture in Zone2 is Normal\n");
			strcpypgm2ram(guchSoilMoisitureZone2_LCD,"SMZ2=N  ");
		 	fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_9);
	     	fn_Display_String_LCD(guchSoilMoisitureZone2_LCD);
		
		}
		
	
		
		
	   if(unDataUploadTowebsiteCounter==5)
	   {
		   
			unDataUploadTowebsiteCounter=0;   
		   fnSensorDataToWebs1ite();
	   
	   }
	   
		   unDataUploadTowebsiteCounter++;
		
	   
	   
	   
	   
	   
	   
	   
	   
		
			delay_in_half_seconds(1);
	//	if(unSoil_MoistSensor_output	<=		50)
	//	{
			
	//	}
		
		
		
		
		
	}
}	


void fnFertilizerInput()
{

 unsigned int i;
 unsigned char Rfidreceive_data[20];
 printf("enter the card\n\r");
 	strcpypgm2ram(guchLCDLine1String," FERTLIZER INPUT  ");
	strcpypgm2ram(guchLCDLine2String,"                  ");
	fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
	fn_Display_String_LCD(guchLCDLine1String);
	fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_0);
	fn_Display_String_LCD(guchLCDLine2String);
 

	SerialData = uchfnReceive_Serial(UART2);	
		while(SerialData =='$');
		{
			for(i = 0;i < 10;i++)
				{
					Rfidreceive_data[i]=uchfnReceive_Serial(UART2);
				}
				Rfidreceive_data[i] = 0;
		 		fnUARTPutString(Rfidreceive_data,UART1);
                delay_in_half_seconds(2);
              	//fnSendStringToInternalEEPROM(Rfidreceive_data, INTERNALEEPROMSTARTADDRESS);
                
               // fnCodeModule();

                printf("starts comparison\r\n");
		if(strstrrampgm(Rfidreceive_data,RFID_FERTILZER1))
		{
                    printf("Valid Fertilizer\n\r");
                    
                    //LCD fn VALID 
                    strcpypgm2ram(guchLCDLine1String," VALID FERTILIZER ");
					strcpypgm2ram(guchLCDLine2String,"                  ");
					fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine1String);
					fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine2String);
                   
                    delay_in_seconds(2);
                    strcpypgm2ram(guchDatatoWebFertiliZer,RFID_FERTILZER1);
                 
             	}
				
					 	if(strstrrampgm(Rfidreceive_data,RFID_FERTILZER2))
				{
                    printf("Valid Fertilizer\n\r");
                    
                    //LCD fn VALID 
                    
                    strcpypgm2ram(guchLCDLine1String," VALID FERTILIZER ");
					strcpypgm2ram(guchLCDLine2String,"                  ");
					fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine1String);
					fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine2String);
                   
                    delay_in_seconds(2);
                    strcpypgm2ram(guchDatatoWebFertiliZer,RFID_FERTILZER2);
                 
             	}	
		   else 
				{ 
                    printf("NOT VALIDFertilzer\n\r");
                    //LCD fn  NOT VALID
                    
                    strcpypgm2ram(guchLCDLine1String,"    INVALID       ");
					strcpypgm2ram(guchLCDLine2String,"    FERTILIZER    ");
					fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine1String);
					fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine2String);
                    
                    
                    delay_in_seconds(2);

    			}             

}

}

void fnPestcideInput()
{
 unsigned int i;
 unsigned char Rfidreceive_data[20];

	SerialData = uchfnReceive_Serial(UART2);	
		while(SerialData =='$');
		{
			for(i = 0;i < 10;i++)
				{
					Rfidreceive_data[i]=uchfnReceive_Serial(UART2);
				}
				Rfidreceive_data[i] = 0;
		 		fnUARTPutString(Rfidreceive_data,UART2);
                delay_in_half_seconds(2);
              	//fnSendStringToInternalEEPROM(Rfidreceive_data, INTERNALEEPROMSTARTADDRESS);
                
               // fnCodeModule();

                printf("starts comparison\r\n");
		 	if(strstrrampgm(Rfidreceive_data,RFID_PESTICIDE1))
				{
                    printf("Valid Pesticide\n\r");
                    
                    
                    
                    //LCD fn VALID 
                    
                    
                    
                    strcpypgm2ram(guchLCDLine1String,"      VALID       ");
					strcpypgm2ram(guchLCDLine2String,"    PESTICIDE     ");
					fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine1String);
					fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine2String);
                    
                   
                    delay_in_seconds(2);
                strcpypgm2ram(guchDatatoWebPesticide,RFID_PESTICIDE1);
                 
             	}
         if(strstrrampgm(Rfidreceive_data,RFID_PESTICIDE2))
				{
                    printf("Valid Pesticide\n\r");
                    
                    //LCD fn VALID 
                   
                    
                    strcpypgm2ram(guchLCDLine1String,"      VALID       ");
					strcpypgm2ram(guchLCDLine2String,"    PESTICIDE     ");
					fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine1String);
					fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine2String);
                   
                   
                    delay_in_seconds(2);
                    strcpypgm2ram(guchDatatoWebPesticide,RFID_PESTICIDE2);
                 
             	}
 	
				
		   else 
				{ 
                    printf("NOT Pesticide\n\r");
                    //LCD fn  NOT VALID
                    
                    
                    strcpypgm2ram(guchLCDLine1String,"     INVALID      ");
					strcpypgm2ram(guchLCDLine2String,"    PESTICIDE     ");
					fn_lcd_select_line_and_location(LCD_LINE_1,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine1String);
					fn_lcd_select_line_and_location(LCD_LINE_2,LOCATION_0);
					fn_Display_String_LCD(guchLCDLine2String);
                    delay_in_seconds(2);

    			}             

}

}


void fnSensorDataToWebs1ite()///Created After Website Design
{


}




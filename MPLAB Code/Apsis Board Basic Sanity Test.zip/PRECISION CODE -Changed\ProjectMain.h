		
void fnMain_Project(void);



void fnFertilizerInput();
void fnSensorDataToWebs1ite();
void fnPestcideInput();





/*
    filename	:serial_codes.h
	description	:transmit and receive data by serial port
	author		:apsis_team
	date		:18.10.2011
*/

#ifndef __SERIAL_CODES_H__
#define __SERIAL_CODES_H__

#define UART1 0
#define UART2 1
#define TIMED_OUT 256 // Any Value more than 0xFF

unsigned char uchfnReceive_Serial(unsigned char UART_NO);
void fn_Initialize_Serial(unsigned char uchSelectUART);
//void fnTransmit_Serial(unsigned char uchTransmit_data,unsigned char uchSelectUART);
unsigned char uchfnReceiveNew_Serial();
void fnUARTPutStringDelayed(unsigned char* string,unsigned char uchSelectUART) ;
#endif




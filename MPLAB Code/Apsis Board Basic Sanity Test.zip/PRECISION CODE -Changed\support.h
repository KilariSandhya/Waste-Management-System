/*
	filename	:support.h
	description	:
	author		:apsis_team
	date		:18.10.2011
*/


#ifndef  __SUPPORT_H_
#define  __SUPPORT_H_




/************************ P R O T O T Y P E ***************************************************
      					External Definitions
***************************************************************************************************/


extern void bin_2_bcd(unsigned int);   // Refer Math.C


extern void _Debounce(void);

extern void bin_2_bcd(unsigned int ); // Ref Math.c
extern void Bin2BCD (unsigned char); // Ref Math.c

#endif


/*
    filename	:strings.h
	description	:
	author		:apsis_team
	date		:18.10.2011
*/

#ifndef __NITIN_H
#define __NITIN_H

unsigned char code string_IAmActive[] = 		{"   I Am Active  "};
unsigned char code string_welcome[]   = 		{"     SJMIT      "};  
unsigned char code string_project_name[]   = 	{" Dam Management "};    
unsigned char code string_project_Partners[]=	{"Project partners"};
// when defining 2D array provide one extra space in the end to take care of /0
unsigned char code string_names[4][17]   = 	   	{
												{"    Name 1      "},
												{"    Name 2      "},
												{"    Name 3      "},
												{"    Name 4      "}
												}; 




#endif /* end of file */

